# HTML & CSS I - Module Project

## Instructions

1. Open the `index.html` file in both VSCode and the Chrome browser:
    - VSCode is where you will make changes to the code.
    - Chrome is where you will check if your code is working correctly.
2. In Chrome, open Dev Tools, Elements tab.
3. Return to VSCode and start working on your Challenges.
4. When you want to check if your code is correct, save changes, go to Chrome and refresh the page.
