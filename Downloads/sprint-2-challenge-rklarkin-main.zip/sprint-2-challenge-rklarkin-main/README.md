# Sprint 2 Challenge

## Instructions

1. Open the `index.html` file in both VSCode and the Chrome browser.
2. In Chrome, open Dev Tools, Console tab.
3. Return to VSCode and start working on your Challenges.
4. You can see tests running in your Console.
5. Submit the completed project to Codegrade following the instructions found in your learning platform.
